a=3
b=4
c=5
d=6

if a**3+b**3+c**3 ==d**3:
    print('codnition is match')
else:
    print('condition is not match')
          
