name = input('enter name :')
hs = int(input('enter mark is hindi '))
es = int(input('enter mark is eng '))
cs = int(input('enter mark is comp. '))
ms = int(input('enter mark is math. '))


total = hs+es+cs+ms
print('name is ',name)
print('total score is ',total)



#####
a = int(input('enter data :'))
b = int(input('enter data :'))

c = a+b

print('sum of a and b is c ')
print('sum of ',a,' and ',b,' is ',c)

#format 
print('sum of {} and {} is {} '.format(a,b,c))
print('sum of {1} and {0} is {2} '.format(a,b,c))






