n1 =11
n2 =89

n = n1*n2

print(n)

