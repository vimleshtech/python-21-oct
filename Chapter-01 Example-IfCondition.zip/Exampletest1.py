name = str(input('enter name :'))
roll =int(input('enter roll no:'))
hs = int(input('enter mark is hindi '))
es = int(input('enter mark is eng '))
cs = int(input('enter mark is comp. '))
ms = int(input('enter mark is math. '))
hi= int( input('enter mark of his.'))

total = hs+es+cs+ms+hi

avg= total /5
print('name is ',name)
print('roll no',roll)
print('total score is ',total)
print('Avg mark is',avg)

