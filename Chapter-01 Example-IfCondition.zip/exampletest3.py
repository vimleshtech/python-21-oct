a = int(input('enter data :'))

t=0
b=50
if a<=100:
    t=(a*.40)
elif a<=300:
    t=40+ (a-100)*.50
    
else:
    t=140+ (a-300)*.60

d=t+b
print(d)

