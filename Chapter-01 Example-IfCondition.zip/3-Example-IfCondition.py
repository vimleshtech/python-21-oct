
amt = int(input('enter sale amt :'))

t = 0
#python is identation based language 

if amt>1000:
    t = amt*.18

total = amt +t
print('total amt is ',total)

    

#if else
t = 0
#python is identation based language 

if amt>1000:
    t = amt*.18

else:
    t = amt*.12

total = amt +t
print('total amt is ',total)


#if elif elif ..
t = 0
#python is identation based language 

if amt>1000:
    t = amt*.18
elif amt>500:
    t = amt*.12
elif amt>200:
    t = amt*.10
else:
    t = amt*.05

    
total = amt +t
print('total amt is ',total)

    



    
    
    
